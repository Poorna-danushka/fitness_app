import mongoose from 'mongoose';

const workoutSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    exerciseId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Exercise',
      required: true,
    },
    duration: {
      type: Number,
      required: true,
      min: 1,
    },
    sets: {
      type: Number,
      min: 1,
      default: null,
    },
    reps: {
      type: Number,
      min: 1,
      default: null,
    },
    caloriesBurned: {
      type: Number,
      default: 0,
    },
    date: {
      type: Date,
      required: true,
      default: Date.now,
    },
    completedForDay: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

// Auto-calculate calories before save
workoutSchema.pre('save', async function (next) {
  if (this.isNew || this.isModified('duration') || this.isModified('exerciseId')) {
    try {
      const Exercise = mongoose.model('Exercise');
      const exercise = await Exercise.findById(this.exerciseId);
      if (exercise) {
        const calPer10 = exercise.caloriesPer10Min || 150; // Fallback to 150 if not specified
        this.caloriesBurned = Math.round((calPer10 * this.duration) / 10);
      }
    } catch (e) {
      // non-critical
    }
  }
  next();
});

export default mongoose.model('Workout', workoutSchema);
